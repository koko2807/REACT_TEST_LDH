import React from 'react';
import ReadContainer from '../../containers/board/ReadContainer';

const Read = () => {

  return (
    <>
      <ReadContainer />
    </>
  );
};

export default Read;
