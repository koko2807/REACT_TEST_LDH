import React from 'react';
import ListContainer from '../../containers/board/ListContainer';

const List = () => {
  return (
    <>
      <ListContainer />
    </>
  );
};

export default List;
