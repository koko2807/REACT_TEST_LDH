import React from 'react';
import InsertContainer from '../../containers/board/InsertContainer';

const Insert = () => {
  return (
    <>
      <InsertContainer />
    </>
  );
};

export default Insert;
